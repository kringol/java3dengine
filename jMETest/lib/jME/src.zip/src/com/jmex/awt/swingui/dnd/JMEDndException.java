package com.jmex.awt.swingui.dnd;

/**
 * @author Galun
 */
public class JMEDndException extends Exception {

    private static final long serialVersionUID = -398658764587033142L;

    public JMEDndException( String msg ) {
        super( msg );
    }
}
