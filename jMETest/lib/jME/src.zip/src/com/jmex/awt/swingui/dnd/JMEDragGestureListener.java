package com.jmex.awt.swingui.dnd;

/**
 * @author Galun
 */
public interface JMEDragGestureListener {

    public void dragGestureRecognized( JMEDragGestureEvent dge );
}
